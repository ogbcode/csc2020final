export enum Gender {
    Female = 'female',
    Male = 'male'
}

export enum ModeOfEntry{
    UTME = 'UTME',
    DE = 'Direct Entry',
    Transfer = 'Transfer'
}